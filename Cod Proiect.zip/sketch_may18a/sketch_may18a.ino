#include <Wire.h>
#include <LiquidCrystal.h>
#include <Servo.h>
#include <DHT.h>
#include <Keypad_I2C.h>
#include <Keypad.h>

// LCD (RS, E, D4, D5, D6, D7)
LiquidCrystal lcd(7, 6, 5, 4, 3, 2);

// DHT11
#define DHTPIN 9
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// SERVO
Servo lockServo;
#define SERVO_PIN 8

// OUTPUTS
#define BUZZER 12
#define LED_GREEN 10
#define LED_RED 11

// I2C KEYPAD (PCF8574)
#define I2CADDR 0x20

const byte ROWS = 4;
const byte COLS = 4;

char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

byte rowPins[ROWS] = {0,1,2,3};
byte colPins[COLS] = {4,5,6,7};

Keypad_I2C keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS, I2CADDR);

// LOGIC
String input = "";
String password = "1234";

// SETUP
void setup()
{
  Wire.begin();

  lcd.begin(16,2);
  dht.begin();

  keypad.begin();

  lockServo.attach(SERVO_PIN);
  lockServo.write(0);

  pinMode(BUZZER, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_RED, OUTPUT);

  lcd.print("SYSTEM READY");
  delay(1500);
  lcd.clear();
}

// LOOP
void loop()
{
  char key = keypad.getKey();

  // KEY INPUT 
  if (key)
  {
    if (key == '#')
    {
      lcd.clear();

      if (input == password)
      {
        lcd.print("ACCESS GRANTED");

        lockServo.write(90);

        digitalWrite(LED_GREEN, HIGH);
        digitalWrite(LED_RED, LOW);
        tone(BUZZER, 1000, 200);

        delay(3000);

        lockServo.write(0);
      }
      else
      {
        lcd.print("ACCESS DENIED");

        digitalWrite(LED_GREEN, LOW);
        digitalWrite(LED_RED, HIGH);
        tone(BUZZER, 200, 500);
      }

      input = "";
      delay(1500);
      lcd.clear();
    }

    else if (key == '*')
    {
      input = "";
      lcd.clear();
    }

    else
    {
      input += key;
      lcd.setCursor(0,0);
      lcd.print("CODE: ");
      lcd.print(input);
    }
  }

  // DHT 
  float t = dht.readTemperature();
  float h = dht.readHumidity();

  lcd.setCursor(0,1);

  if (isnan(t) || isnan(h))
  {
    lcd.print("Sensor Error   ");
  }
  else
  {
    lcd.print("T:");
    lcd.print(t);
    lcd.print(" H:");
    lcd.print(h);
    lcd.print("   ");
  }

  delay(200);
}